﻿// Copyright lurongjiu 2024 All Rights Reserved.

#pragma once
#include "CoreMinimal.h"
#include "Engine/DeveloperSettings.h"

#include "ColorOutlinerSettings.generated.h"

struct FColorOutlinerSettingsDelegates
{
	DECLARE_MULTICAST_DELEGATE(FOnPostEditChangeProperty);
	//FOnPostEditChangeProperty& GetOnPostEditChangeProperty() {return OnPostEditChangeProperty;}
	
	static FOnPostEditChangeProperty OnPostEditChangeProperty;
};

UCLASS(config = Engine, defaultconfig)
class UColorOutlinerSettings : public UDeveloperSettings
{
public:
	GENERATED_BODY()
	
	UColorOutlinerSettings();
	
	//~ Begin UDeveloperSettings interface
	//大分类, 若不存在新建分类
	virtual FName GetCategoryName() const override;
#if WITH_EDITOR
	//大类下二级分类, 一般为插件名
	virtual FText GetSectionText() const override;
	virtual FName GetSectionName() const override;
	virtual FText GetSectionDescription() const override;

	//~ End UDeveloperSettings interface
	
	/** UObject interface */
	//任何属性值修改将调用
	virtual void PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent) override;

#endif
	/*In order to more prominently identify the item whose color you've set, you can choose to set the color of the label text simultaneously.*/
	UPROPERTY(config, EditAnywhere, Category = "ColorOptions", DisplayName = "Simultaneously Setting Text Color",meta = (ConfigRestartRequired = false))
	bool bSimultaneouslySettingTextColor = false;

	/*Set the default color for folders in the outliner*/
	UPROPERTY(config, EditAnywhere, Category = "ColorOptions", DisplayName = "Default Outliner Folder Color",meta = (ConfigRestartRequired = false))
	FLinearColor DefaultFolderColor;

	/*Reset the default color for folders in the outliner*/
	UPROPERTY(config, EditAnywhere, Category = "ColorOptions", DisplayName = "Reset Folder Default Color",meta = (ConfigRestartRequired = false))
	bool ResetFolderColor = false;

	/*Set the default color for actors in the outliner*/
	UPROPERTY(config, EditAnywhere, Category = "ColorOptions", DisplayName = "Default Outliner Actor Color",meta = (ConfigRestartRequired = false))
	FLinearColor DefaultActorColor;

	/*Reset the default color for actors in the outliner*/
	UPROPERTY(config, EditAnywhere, Category = "ColorOptions", DisplayName = "Reset Outliner Actor Default Color",meta = (ConfigRestartRequired = false))
	bool ResetActorColor = false;

	/*Export the color for all level actors in the project in the Outliner (excluding default color settings).*/
	UPROPERTY(config, EditAnywhere, Category = "ColorTools", DisplayName = "Export Actors Color List",meta = (ConfigRestartRequired = false))
	bool ExportActorsColorList = false;

	/*Import from the actors' color list to the current project.*/
	UPROPERTY(config, EditAnywhere, Category = "ColorTools", DisplayName = "Import Actors Color List",meta = (ConfigRestartRequired = false))
	bool ImportActorsColorList = false;	
	
};
