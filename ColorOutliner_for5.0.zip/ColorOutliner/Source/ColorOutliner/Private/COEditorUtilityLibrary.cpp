// Copyright lurongjiu 2024 All Rights Reserved.


#include "COEditorUtilityLibrary.h"
#include "ColorOutlinerUtils.h"


#if WITH_EDITOR
#include "SSceneOutliner.h"
#include "LevelEditor.h"
	
#endif

FLinearColor UCOEditorUtilityLibrary::GetActorItemColor(const AActor* Actor)
{
#if WITH_EDITOR
	if (Actor == nullptr) return FLinearColor(-1,-1,-1,-1);
	
	const FString FullPath = SceneOutlinerFolderUtils::GetActorFullPath(Actor);
	
	TOptional<FLinearColor> TColor = SceneOutlinerFolderUtils::IsActorInTempMap(FullPath)?
				SceneOutlinerFolderUtils::GetColorByPathTemp(Actor->GetActorGuid().ToString()) : SceneOutlinerFolderUtils::GetColorByPath(FullPath,false);

	if(TColor.IsSet())
	{
		if(!TColor.GetValue().Equals(SceneOutlinerFolderUtils::GetOutlinerItemSetColor(false)))
		{
			return TColor.GetValue();
		}
	}
#endif
	return FLinearColor::White;
}

void UCOEditorUtilityLibrary::SetActorItemColor(const AActor* Actor, const FLinearColor Color,const bool Refresh)
{
#if WITH_EDITOR
	if (Actor == nullptr) return;
	
	const FString FullPath = SceneOutlinerFolderUtils::GetActorFullPath(Actor);
	
	SceneOutlinerFolderUtils::IsActorInTempMap(FullPath)?
		SceneOutlinerFolderUtils::SaveColorWithPathTemp(Actor->GetActorGuid().ToString(),Color,false):
		SceneOutlinerFolderUtils::SaveColorWithPath(FullPath,Color,false);
	

	if(Refresh)
	{
		RefreshSceneOutliners();
	}
#endif
}

void UCOEditorUtilityLibrary::ClearActorItemColor(const AActor* Actor, const bool Refresh)
{
#if WITH_EDITOR
	if (Actor == nullptr) return;
	
	const FString FullPath = SceneOutlinerFolderUtils::GetActorFullPath(Actor);
	
	SceneOutlinerFolderUtils::IsActorInTempMap(FullPath)?
		SceneOutlinerFolderUtils::DeleteFullPathFromTemp(Actor->GetActorGuid().ToString()):
		SceneOutlinerFolderUtils::DeleteFullPathFromConfig(FullPath);
	

	if(Refresh)
	{
		RefreshSceneOutliners();
	}
#endif
}



void UCOEditorUtilityLibrary::RefreshSceneOutliners()
{
#if WITH_EDITOR
	const FLevelEditorModule& LevelEditorModule = FModuleManager::LoadModuleChecked<FLevelEditorModule>(TEXT("LevelEditor"));
#if ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION >= 1
	for(const TWeakPtr<ISceneOutliner>& Outliner : LevelEditorModule.GetFirstLevelEditor()->GetAllSceneOutliners())
	{
		if(Outliner.Pin().IsValid())
		{
			Outliner.Pin()->FullRefresh();
		}
	}
#else
	if(const TSharedPtr<ISceneOutliner> SceneOutliner = LevelEditorModule.GetFirstLevelEditor()->GetSceneOutliner();
		SceneOutliner.IsValid())
	{
		SceneOutliner->FullRefresh();
	}
#endif
	
#endif
}
