// Copyright lurongjiu 2024 All Rights Reserved.

#include "ColorOutlinerModule.h"

#if WITH_EDITOR
#include "LevelUtils.h"
#include "LevelEditor.h"
#include "SceneOutlinerModule.h"
#include "ColorOutlinerUtils.h"
#include "SceneOutlinerMenuContext.h"
#include "SSceneOutliner.h"
#include "ToolMenu.h"
#include "ToolMenuDelegates.h"
#include "ToolMenuEntry.h"
#include "ToolMenuSection.h"
#include "ToolMenus.h"
#include "Widgets/Colors/SColorPicker.h"
#include "ActorFolderTreeItem.h"
#include "ActorTreeItem.h"
#include "ColorOutlinerSettings.h"
#include "FSOItemLabelColumnReplace.h"
//#include "SOutlinerTreeView.h"
#include "SceneOutlinerItemLabelColumn.h"
#include "Editor.h"
#include "EditorActorFolders.h"
#include "EditorLevelUtils.h"
#include "Subsystems/EditorActorSubsystem.h"

#include "COEditorUtilityLibrary.h"
#endif

#define LOCTEXT_NAMESPACE "FColorOutlinerModule"

#if WITH_EDITOR
namespace OFUtils = SceneOutlinerFolderUtils;

enum class EMouseEvent : uint8
{
	Default = 0,
	Press = 1,
	Release = 2
};
#endif

void FColorOutlinerModule::StartupModule()
{
#if WITH_EDITOR
	RegisterOnMapRename();
	RegisterOnMapDeleted();
	RegisterOnMapChanged();
	RegisterOnFolderOperate();
	RegisterOnActorDelete();
	RegisterOnMoveActorsToLevel();
	RegisterOnBlueprintCompile();
	RegisterOutlinerItemLabelColumn();
	RegisterOutlinerContextMenuExtend();
	
#if ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION >= 1
	RegisterTintedFilter();
#endif
	
	RegisterOnSettingsChanged();
	RegisterOnChangedPIEState();
	RegisterOnActiveTabChanged();
	RegisterTickerCheckLevelLockState();

	
#endif
}

void FColorOutlinerModule::ShutdownModule()
{
#if WITH_EDITOR
	/*UnregisterOnMapRename*/
	if(FWorldDelegates::OnPreWorldRename.Remove(OnPreWorldRenameHandle))
	{
		OnPreWorldRenameHandle.Reset();
	}
	if(FWorldDelegates::OnPostWorldRename.Remove(OnPostWorldRenameHandle))
	{
		OnPostWorldRenameHandle.Reset();
	}
	
	/*UnregisterOnMapDeleted*/
	if(FEditorDelegates::OnAssetsPreDelete.Remove(OnAssetsPreDeleteHandle))
	{
		OnAssetsPreDeleteHandle.Reset();
	}
	if(FEditorDelegates::OnAssetsDeleted.Remove(OnAssetsDeletedHandle))
	{
		OnAssetsDeletedHandle.Reset();
	}
	
	/*UnregisterOnMapChanged*/
	FLevelEditorModule& LevelEditorModule = FModuleManager::LoadModuleChecked<FLevelEditorModule>(TEXT("LevelEditor"));
	if(LevelEditorModule.OnMapChanged().Remove(OnMapChangedHandle))
	{
		OnMapChangedHandle.Reset();
	}
	
	/*UnregisterOnFolderOperate*/
	if(FActorFolders::OnFolderMoved.Remove(OnFolderMovedHandle))
	{
		OnFolderMovedHandle.Reset();
	}
	if(FActorFolders::OnFolderDeleted.Remove(OnFolderDeletedHandle))
	{
		OnFolderDeletedHandle.Reset();
	}

	if(GEngine!=nullptr)
	{
		if(GEngine->OnLevelActorDeleted().Remove(OnLevelActorDeleted))
		{
			OnLevelActorDeleted.Reset();
		}
	}

	if(UEditorLevelUtils::OnMoveActorsToLevelEvent.Remove(OnMoveActorsToLevel))
	{
		OnMoveActorsToLevel.Reset();
	}

	if(GEditor)
	{
		if(GEditor->OnBlueprintPreCompile().Remove(OnBlueprintPreCompile))
		{
			OnBlueprintPreCompile.Reset();
		}
		if(GEditor->OnBlueprintCompiled().Remove(OnBlueprintCompiled))
		{
			OnBlueprintCompiled.Reset();
		}
	}
	
	/*UnregisterOutlinerItemLabelColumn*/
	FSceneOutlinerModule& SceneOutlinerModule = FModuleManager::LoadModuleChecked<FSceneOutlinerModule>(TEXT("SceneOutliner"));
	SceneOutlinerModule.UnRegisterColumnType<FSOItemLabelColumnReplace>();

	if(FColorOutlinerSettingsDelegates::OnPostEditChangeProperty.Remove(OnSettingsChangedHandle))
	{
		OnSettingsChangedHandle.Reset();
	}
	
	if(FColorOutlinerSettingsDelegates::OnPostEditChangeProperty.Remove(OnIOExecuteHandle))
	{
		OnIOExecuteHandle.Reset();
	}
	
	OFUtils::ClearCache();
	InitialPropertyCache();

	if(FEditorDelegates::PostPIEStarted.Remove(OnPIEStartedDelegate))
	{
		OnPIEStartedDelegate.Reset();
	}
	if(FEditorDelegates::EndPIE.Remove(OnPIEEndedDelegate))
	{
		OnPIEEndedDelegate.Reset();
	}

	if(OnActiveTabChangedHandle.IsValid())
	{
		FGlobalTabmanager::Get()->OnActiveTabChanged_Unsubscribe(OnActiveTabChangedHandle);
		OnActiveTabChangedHandle.Reset();
	}
	
	if(TickCheckLevelLockStateHandle.IsValid())
	{
		FTSTicker::GetCoreTicker().RemoveTicker(TickCheckLevelLockStateHandle);
		TickCheckLevelLockStateHandle.Reset();
	}
	
#endif
}

#if WITH_EDITOR

void FColorOutlinerModule::RegisterOnMapRename()
{
	OnPreWorldRenameHandle = FWorldDelegates::OnPreWorldRename.AddLambda([](UWorld* World, const TCHAR* InName, UObject* NewOuter, ERenameFlags Flags, bool& bShouldFailRename)
	{
		OFUtils::OnPreWorldRename(World);
	});

	OnPostWorldRenameHandle = FWorldDelegates::OnPostWorldRename.AddLambda([](UWorld* World)
	{
		OFUtils::OnPostWorldRename(World);
	});
}



void FColorOutlinerModule::RegisterOnMapDeleted()
{
	OnAssetsPreDeleteHandle = FEditorDelegates::OnAssetsPreDelete.AddLambda([](const TArray<UObject*>& Objects)
	{
		OFUtils::OnWorldPreDelete(Objects);
	});
	
	OnAssetsDeletedHandle = FEditorDelegates::OnAssetsDeleted.AddLambda([](const TArray<UClass*>& Classes)
	{
		OFUtils::OnWorldDeleted();
	});
}

void FColorOutlinerModule::RegisterOnMapChanged()
{
	FLevelEditorModule& LevelEditorModule = FModuleManager::LoadModuleChecked<FLevelEditorModule>(TEXT("LevelEditor"));
	
	OnMapChangedHandle = LevelEditorModule.OnMapChanged().AddLambda([&](const UWorld* World, const EMapChangeType MapChangeType)
	{
		IsCurrentPartitionedWorld = World->IsPartitionedWorld();
		if(IsCurrentPartitionedWorld)
		{
			CurrentWorld.Reset();
		}
		else
		{
			CurrentWorld = TWeakObjectPtr<UWorld>((UWorld*)World);
		}
		
		FString NowMapPath;
		switch (MapChangeType)
		{
			case EMapChangeType::LoadMap:
				/*Template or existing*/
				NowMapPath = World->GetPathName();
				if(NowMapPath.StartsWith(TEXT("/Temp"),ESearchCase::CaseSensitive))
				{
					OFUtils::SaveIsTempMap(true);
				}
				else
				{
					OFUtils::SaveIsTempMap(false);
					NowMapPath.RemoveFromEnd(TEXT(".")+World->GetMapName());
					NowMapPath.Append(TEXT("/"));
					OFUtils::SaveCurrentMapPath(NowMapPath);
				}
			break;
		
			case EMapChangeType::NewMap:
				/*Empty level*/
				OFUtils::SaveIsTempMap(true);
			break;
		
			case EMapChangeType::SaveMap:
				/*Is template or empty level to save?*/
				if(OFUtils::GetIsTempMap())
				{
					OFUtils::TempToSave(World);
				}
			break;
		
			case EMapChangeType::TearDownWorld:
				/*Clear cache*/
				OFUtils::SaveCurrentMapPath(FString());
				OFUtils::ClearColorsTemp();
			break;
		}
	});
}

void FColorOutlinerModule::RegisterOnFolderOperate()
{
	OnFolderMovedHandle = FActorFolders::OnFolderMoved.AddLambda([](const UWorld& World, const FFolder& Source, const FFolder& Dest)
	{
		OFUtils::SaveIsFolderMoved(true);
		
		//运行时, 移动操作会在停止后被还原, 运行时移动应复制一份颜色,但较复杂且该操作几乎不可能被执行, 且影响不大. 故忽略
		if(World.IsPlayInEditor()) return;
		
		OFUtils::UpdateFolderFullPath(Source,Dest);
	});
	
	OnFolderDeletedHandle = FActorFolders::OnFolderDeleted.AddLambda([](const  UWorld& World, const FFolder& DeletedFolder )
	{
		if(!OFUtils::GetIsFolderMoved())
		{
			//运行时, 删除操作会在停止后被还原, 故不清除颜色
			if(World.IsPlayInEditor()) return;
			
			/*Not move,means delete*/
			OFUtils::DeleteFolderFullPath(DeletedFolder);
		}
		else
		{
			OFUtils::SaveIsFolderMoved(false);
		}
	});
}

void FColorOutlinerModule::RegisterOnActorDelete()
{
	if(GEngine==nullptr) return;
	OnLevelActorDeleted = GEngine->OnLevelActorDeleted().AddLambda([](const AActor* ActorDeleted)
	{
		if(OFUtils::GetCanDeleteActorsExecute())
		{
			OFUtils::DeleteActorFullPath(ActorDeleted);
		}
	});
}



void FColorOutlinerModule::RegisterOnMoveActorsToLevel()
{
	/*
	 *When executing the movement of Actors to another streaming level,
	 *the actual process involves deleting the original actors and regenerating identical actors in the new level.
	 *However, the Guids of the new actors will be refreshed.
	 */
	OnMoveActorsToLevel = UEditorLevelUtils::OnMoveActorsToLevelEvent.AddLambda([](const TArray<AActor*>& ActorsToDelete, const ULevel* DestLevel)
	{
		for(AActor* CurrentActorToDelete : ActorsToDelete)
		{
			if(CurrentActorToDelete==nullptr) continue;
			/*
			 *Although they are not the same AActor objects programmatically, their properties need to be copied completely, such as Tags.
			 *Therefore, during the deletion process,the item's color information is saved into the Tags,
			 *and upon generation, it is retrieved and the saved Tag is removed.
			 */
			const FString FullPath = OFUtils::GetActorFullPath(CurrentActorToDelete);
			
			TOptional<FLinearColor> TColor = OFUtils::IsActorInTempMap(FullPath)?
				OFUtils::GetColorByPathTemp(CurrentActorToDelete->GetActorGuid().ToString()) : OFUtils::GetColorByPath(FullPath,false);
			
			if(TColor.IsSet())
			{
				if(!TColor.GetValue().Equals(OFUtils::GetOutlinerItemSetColor(false)))
				{
					FName FNColor = FName(FString(TColor->ToString()));
					
					CurrentActorToDelete->Tags.AddUnique(FName(OFUtils::GetSectionName()));
					CurrentActorToDelete->Tags.AddUnique(FNColor);
					/*
					 * There is no need to explicitly perform a cleanup operation on the config,
					 * as the OnMoveActorsToLevelEvent automatically triggers a OnActorDeleted callback.
					 */
				}
			}
		}
		/*
		 * The retrieval process must be delayed for one frame since the actor accessed in the current frame is still the original one,
		 * and any operations performed on it will be carried out before destruction.
		 * After a frame delay, the Tags will be read, and the color information will be saved to the configuration.
		 */
		FTimerManager& TimerManager = DestLevel->GetWorld()->GetTimerManager();
		TimerManager.SetTimerForNextTick(
			FTimerDelegate::CreateLambda([]()
			{
				TArray<AActor*> ActorsToAdd= GEditor->GetEditorSubsystem<UEditorActorSubsystem>()->GetSelectedLevelActors();
				for(AActor* CurrentActorToAdd : ActorsToAdd)
				{
					if(CurrentActorToAdd==nullptr) continue;
					
					int FindIndex;
					if(CurrentActorToAdd->Tags.Find(FName(OFUtils::GetSectionName()),FindIndex))
					{
						if(FindIndex+2 == CurrentActorToAdd->Tags.Num())
						{
							FLinearColor FLColor;
							FLColor.InitFromString(CurrentActorToAdd->Tags[FindIndex+1].ToString());

							const FString FullPath = OFUtils::GetActorFullPath(CurrentActorToAdd);
							
							OFUtils::IsActorInTempMap(FullPath)?
								OFUtils::SaveColorWithPathTemp(CurrentActorToAdd->GetActorGuid().ToString(),FLColor,false):
								OFUtils::SaveColorWithPath(FullPath,FLColor,false);
							
							CurrentActorToAdd->Tags.SetNum(FindIndex);
						}
					}
				}
			})
		);
	});
}

void FColorOutlinerModule::RegisterOnBlueprintCompile()
{
	if(!GEditor) return;
	
	OnBlueprintPreCompile = GEditor->OnBlueprintPreCompile().AddLambda([](const UBlueprint* Blueprint)
	{
		OFUtils::SetCanDeleteActorsExecute(false);
	});

	OnBlueprintCompiled = GEditor->OnBlueprintCompiled().AddLambda([]()
	{
		OFUtils::SetCanDeleteActorsExecute(true);
	});
}

void FColorOutlinerModule::RegisterOutlinerItemLabelColumn()
{
	FSceneOutlinerModule& SceneOutlinerModule = FModuleManager::LoadModuleChecked<FSceneOutlinerModule>(TEXT("SceneOutliner"));
	SceneOutlinerModule.UnRegisterColumnType<FSceneOutlinerItemLabelColumn>();
	
	//SceneOutlinerModule.RegisterDefaultColumnType<FSOItemLabelColumnReplace>(FSceneOutlinerColumnInfo(ESceneOutlinerColumnVisibility::Visible, 6));
	SceneOutlinerModule.RegisterDefaultColumnType< FSOItemLabelColumnReplace >(FSceneOutlinerColumnInfo(ESceneOutlinerColumnVisibility::Visible, 10, FCreateSceneOutlinerColumn(), false, TOptional<float>(), FSceneOutlinerBuiltInColumnTypes::Label_Localized()));
}

void FColorOutlinerModule::RegisterOutlinerContextMenuExtend()
{
	UToolMenu* Menu = UToolMenus::Get()->ExtendMenu(OFUtils::GetDefaultContextBaseMenuName());
	
	Menu->AddDynamicSection("SetColorSection", FNewToolMenuDelegate::CreateLambda([this](UToolMenu* InMenu)
	{
		const USceneOutlinerMenuContext* Context = InMenu->FindContext<USceneOutlinerMenuContext>();
		if (!Context)
		{
			return;
		}
		FToolMenuSection& Section = InMenu->FindOrAddSection("SceneOutlinerItemOptions");
		Section.Label = LOCTEXT("ItemOptionsLabel", "Item Options");
		
		/*清理缓存*/
		InitialPropertyCache();

		if(Context->NumSelectedItems <= 0) return;
		
		SelectedSceneOutliner = Context->SceneOutliner;
		
		#if ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION >= 1
		const FLevelEditorModule& LevelEditorModule = FModuleManager::LoadModuleChecked<FLevelEditorModule>(TEXT("LevelEditor"));
		
		SceneOutliners = LevelEditorModule.GetFirstLevelEditor()->GetAllSceneOutliners();
		#endif

		/*todo:没有实际作用, 在5.0中删除将导致崩溃, 其他版本可删除, 原因未知*/
		ExecuteItems = SelectedSceneOutliner.Pin()->GetSelectedItems();
		
		/*select and only select folder*/
		if (Context->NumSelectedFolders == Context->NumSelectedItems)
        {
			if(InitialFolderTreeItems())
			{
				Section.AddMenuEntry(
				"OutlinerSetColor",
				LOCTEXT("OutlinerSetColor", "Set Color"),
				LOCTEXT("SetColorTooltip_Folder", "Sets the color this folder should appear as."),
				FSlateIcon(FAppStyle::GetAppStyleSetName(), "Icons.Color"),
				FUIAction( FExecuteAction::CreateRaw( this, &FColorOutlinerModule::OutlinerItemExecutePickColor, true ) )
				);
				
				if(CheckSelectedFoldersSetColor())
				{
					Section.AddMenuEntry(
						"OutlinerClearColor",
						LOCTEXT("OutlinerClearColor", "Clear Color"),
						LOCTEXT("ClearColorTooltip_Folder", "Resets the color this folder appears as."),
						FSlateIcon(),
						FUIAction(FExecuteAction::CreateRaw( this, &FColorOutlinerModule::OutlinerFolderExecuteResetColor ))
					);
				}
			}
        }
		/*only select actors*/
		else if(Context->NumSelectedFolders == 0 && Context->NumWorldsSelected == 0)
		{
			if(InitialActorTreeItems())
			{
				Section.AddMenuEntry(
				"OutlinerSetColor",
				LOCTEXT("OutlinerSetColor", "Set Color"),
				LOCTEXT("SetColorTooltip_Actor", "Sets the color this actor icon should appear as."),
				FSlateIcon(FAppStyle::GetAppStyleSetName(), "Icons.Color"),
				FUIAction( FExecuteAction::CreateRaw( this, &FColorOutlinerModule::OutlinerItemExecutePickColor, false ) )
				);
				
				if(CheckSelectedActorsSetColor())
				{
					Section.AddMenuEntry(
						"OutlinerClearColor",
						LOCTEXT("OutlinerClearColor", "Clear Color"),
						LOCTEXT("ClearColorTooltip_Actor", "Resets the color this actor icon appears as."),
						FSlateIcon(),
						FUIAction(FExecuteAction::CreateRaw( this, &FColorOutlinerModule::OutlinerActorExecuteResetColor ))
					);
				}
			}
		}
	}));
}

void FColorOutlinerModule::OutlinerItemExecutePickColor(const bool bIsFolder)
{
	FLinearColor InitialColor = ExistItemSetColor.IsSet() ? ExistItemSetColor.GetValue() : OFUtils::GetOutlinerItemSetColor(bIsFolder);

	FColorPickerArgs PickerArgs = FColorPickerArgs();
	
#if ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION < 2
	PickerArgs.InitialColorOverride = InitialColor;
#else
	PickerArgs.InitialColor = InitialColor;
#endif
	
	PickerArgs.bUseAlpha = true;
	PickerArgs.OnColorCommitted = FOnLinearColorValueChanged::CreateRaw(this, &FColorOutlinerModule::OnLinearColorValueChanged,bIsFolder);
	PickerArgs.bIsModal = false;

	OpenColorPicker(PickerArgs);
}

void FColorOutlinerModule::OnLinearColorValueChanged(const FLinearColor InColor,bool bIsFolder)
{
	bIsFolder ? OnFolderColorClicked(InColor) : OnActorColorClicked(InColor);
}

FReply FColorOutlinerModule::OnFolderColorClicked(const FLinearColor InColor)
{
	for(const FActorFolderTreeItem* SelectedFolder : ExecuteFolderTreeItems)
	{
		OFUtils::GetIsTempMap()?
			OFUtils::SaveColorWithPathTemp(SelectedFolder->GetPath().ToString(),InColor,true):
			OFUtils::SaveColorWithPath(OFUtils::GetFolderFullPath(SelectedFolder),InColor,true);
		
	}
	RefreshCacheSceneOutliner();
	return FReply::Handled();
}

FReply FColorOutlinerModule::OnActorColorClicked(const FLinearColor InColor)
{
	for(const FActorTreeItem* SelectedActor : ExecuteActorTreeItems)
	{
		const FString FullPath = OFUtils::GetActorFullPath(SelectedActor);
		
		OFUtils::IsActorInTempMap(FullPath)?
			OFUtils::SaveColorWithPathTemp(OFUtils::GetGuidStringFromActorItem(SelectedActor),InColor,false):
			OFUtils::SaveColorWithPath(FullPath,InColor,false);
	}
	RefreshCacheSceneOutliner();
	return FReply::Handled();
}

void FColorOutlinerModule::OutlinerFolderExecuteResetColor()
{
	for(const FActorFolderTreeItem* SelectedFolder : ExecuteFolderTreeItems)
	{
		OFUtils::GetIsTempMap()?
			OFUtils::DeleteFullPathFromTemp(SelectedFolder->GetPath().ToString()):
			OFUtils::DeleteFullPathFromConfig(OFUtils::GetFolderFullPath(SelectedFolder));
	}
	RefreshCacheSceneOutliner();
}

void FColorOutlinerModule::OutlinerActorExecuteResetColor()
{
	for(const FActorTreeItem* SelectedActor : ExecuteActorTreeItems)
	{
		const FString FullPath = OFUtils::GetActorFullPath(SelectedActor);
		OFUtils::IsActorInTempMap(FullPath)?
			OFUtils::DeleteFullPathFromTemp(OFUtils::GetGuidStringFromActorItem(SelectedActor)):
			OFUtils::DeleteFullPathFromConfig(FullPath);
		
	}
	RefreshCacheSceneOutliner();
}

void FColorOutlinerModule::RefreshCacheSceneOutliner()
{
#if ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION >= 1
	for(const TWeakPtr<ISceneOutliner>& Outliner : SceneOutliners)
	{
		if(Outliner.Pin().IsValid())
		{
			Outliner.Pin()->FullRefresh();
		}
	}
#else
	if(SelectedSceneOutliner.Pin().IsValid())
	{
		SelectedSceneOutliner.Pin()->FullRefresh();
	}
#endif
}

#if ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION >= 1
void FColorOutlinerModule::RegisterTintedFilter()
{
	FLevelEditorModule& LevelEditorModule = FModuleManager::LoadModuleChecked<FLevelEditorModule>(TEXT("LevelEditor"));

	//构建主入口
	TSharedPtr<FFilterCategory> FilterCategory = MakeShared<FFilterCategory>(
		LOCTEXT("ColouredFilter","Coloured Filter")/*主入口名称*/,
		LOCTEXT("ColouredFilterTooltip","In the Actor filter, whenever an actor is displayed, its folder hierarchy is also shown, regardless of whether the folder is colored or not.In the Folder filter, similarly, when a folder is displayed, all of its direct actor children will be shown as well.")
		);/*主入口Tooltip*/

	//过滤actor的规则, 返回未着色actor
	auto TintedActorsFilterRule = [](const ISceneOutlinerTreeItem& Item,const bool ShowTinted)->bool
	{
		if(const FActorTreeItem* ActorItem = Item.CastTo<FActorTreeItem>())
		{
			const FString FullPath = OFUtils::GetActorFullPath(ActorItem);
			
			const TOptional<FLinearColor> Color = OFUtils::IsActorInTempMap(FullPath)?
			OFUtils::GetColorByPathTemp(OFUtils::GetGuidStringFromActorItem(ActorItem)) : OFUtils::GetColorByPath(FullPath,false);
				
			if (Color.IsSet())
			{
				//ShowTinted为真:需显示着色actor, color不等于默认颜色时返回真.
				//ShowTinted为假:需显示未着色actor, color等于默认颜色时返回真.
				return ShowTinted == !Color->Equals(OFUtils::GetOutlinerItemSetColor(false));
			}
			//颜色未设置, 可能是默认颜色
			return !ShowTinted;
		}
		//cast失败, 可能是folder, 一律返回false
		return false;
	};

	//过滤器1, 搭配过滤规则1
	const TSharedRef<FGenericFilter<const ISceneOutlinerTreeItem&>> ColouredActorsFilter = MakeShared<FGenericFilter<const ISceneOutlinerTreeItem&>>(
		FilterCategory,
		FString(TEXT("Coloured Actors")),  /*在代码中的命名*/
		LOCTEXT("ColouredActors","Coloured Actors"), /*过滤器显示的命名*/
		FGenericFilter<const ISceneOutlinerTreeItem&>::FOnItemFiltered::CreateLambda([&](const ISceneOutlinerTreeItem& Item)->bool
			{
				return TintedActorsFilterRule(Item,true); /*过滤规则*/
			})
		);
	
	//未着色actors过滤器
	const TSharedRef<FGenericFilter<const ISceneOutlinerTreeItem&>> UncolouredActorsFilter = MakeShared<FGenericFilter<const ISceneOutlinerTreeItem&>>(
		FilterCategory,
		FString(TEXT("Uncoloured Actors")),  /*在代码中的命名*/
		LOCTEXT("UncolouredActors","Uncoloured Actors"), /*过滤器显示的命名*/
		FGenericFilter<const ISceneOutlinerTreeItem&>::FOnItemFiltered::CreateLambda([&](const ISceneOutlinerTreeItem& Item)->bool
			{
				return TintedActorsFilterRule(Item,false);
			})
		);

	//注册所有过滤器 @todo: 函数已废弃建议更新, 但新的函数没有导出, 无定义, 版本更新后检查是否更新代码
	LevelEditorModule.AddCustomFilterToOutliner(ColouredActorsFilter);
	LevelEditorModule.AddCustomFilterToOutliner(UncolouredActorsFilter);


	//folder着色过滤, 仍过滤actor, 但根据其folder着色而非自身
	auto TintedFoldersActorsFilterRule = [](const ISceneOutlinerTreeItem& Item,const bool ShowTinted)->bool
	{
		if(const FActorTreeItem* ActorItem = Item.CastTo<FActorTreeItem>())
		{
			const FFolder& ActorFolder = ActorItem->Actor->GetFolder();
			//const FString ActorFullPath = OFUtils::GetActorFullPath(ActorItem);
			const FString FolderFullPath = OFUtils::GetFolderFullPath(ActorFolder);
			
			TOptional<FLinearColor> Color = OFUtils::GetIsTempMap()?
				OFUtils::GetColorByPathTemp(ActorFolder.GetPath().ToString()) : OFUtils::GetColorByPath(FolderFullPath,true);

			if (Color.IsSet())
			{
				//ShowTinted为真:需显示着色actor, color不等于默认颜色时返回真.
				//ShowTinted为假:需显示未着色actor, color等于默认颜色时返回真.
				return ShowTinted == !Color->Equals(OFUtils::GetOutlinerItemSetColor(true));
			}
			//颜色未设置, 可能是默认颜色
			return !ShowTinted;
		}
		//cast失败, 可能是folder, 一律返回false(actor显示将强制其folder显示
		return false;
	};

	const TSharedRef<FGenericFilter<const ISceneOutlinerTreeItem&>> ColouredFoldersFilter = MakeShared<FGenericFilter<const ISceneOutlinerTreeItem&>>(
		FilterCategory,
		FString(TEXT("Coloured Folders Actors")),  /*在代码中的命名*/
		LOCTEXT("ColouredFoldersActors","Coloured Folders Actors"), /*过滤器显示的命名*/
		FGenericFilter<const ISceneOutlinerTreeItem&>::FOnItemFiltered::CreateLambda([&](const ISceneOutlinerTreeItem& Item)->bool
			{
				return TintedFoldersActorsFilterRule(Item,true);
			})
		);
	
	const TSharedRef<FGenericFilter<const ISceneOutlinerTreeItem&>> UncolouredFoldersFilter = MakeShared<FGenericFilter<const ISceneOutlinerTreeItem&>>(
		FilterCategory,
		FString(TEXT("Uncoloured Folders Actors")),  /*在代码中的命名*/
		LOCTEXT("UncolouredFoldersActors","Uncoloured Folders Actors"), /*过滤器显示的命名*/
		FGenericFilter<const ISceneOutlinerTreeItem&>::FOnItemFiltered::CreateLambda([&](const ISceneOutlinerTreeItem& Item)->bool
			{
				return TintedFoldersActorsFilterRule(Item,false);
			})
		);

	LevelEditorModule.AddCustomFilterToOutliner(ColouredFoldersFilter);
	LevelEditorModule.AddCustomFilterToOutliner(UncolouredFoldersFilter);

}
#endif

void FColorOutlinerModule::RegisterOnSettingsChanged()
{
	OnIOExecuteHandle = FColorOutlinerSettingsDelegates::OnPostEditChangeProperty.AddLambda([]()
	{
		if(const UColorOutlinerSettings* Settings = GetDefault<UColorOutlinerSettings>())
		{
			if(Settings->ExportActorsColorList)
			{
				OFUtils::OnExport();
			}
			else if(Settings->ImportActorsColorList)
			{
				if(OFUtils::OnImport())
				{
					UCOEditorUtilityLibrary::RefreshSceneOutliners();
				}
			}
		}
	});

	OnSettingsChangedHandle = FColorOutlinerSettingsDelegates::OnPostEditChangeProperty.AddStatic(&UCOEditorUtilityLibrary::RefreshSceneOutliners);
}

void FColorOutlinerModule::InitialPropertyCache()
{
#if ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION >= 1
	SceneOutliners.Empty();
#endif
	ExecuteFolderTreeItems.Empty();
	ExecuteActorTreeItems.Empty();
	ExistItemSetColor.Reset();
}

bool FColorOutlinerModule::InitialFolderTreeItems()
{
	const TArray<FSceneOutlinerTreeItemPtr> NowExecuteItems = SelectedSceneOutliner.Pin()->GetSelectedItems();
	const int ExecuteItemsNum = NowExecuteItems.Num();
	ExecuteFolderTreeItems.SetNum(ExecuteItemsNum);
			
	for(int i = 0; i < ExecuteItemsNum; ++i)
	{
		if(FActorFolderTreeItem* SelectedFolder = NowExecuteItems[i]->CastTo<FActorFolderTreeItem>())
		{
			ExecuteFolderTreeItems[i] = SelectedFolder;
		}
		else
		{
			ExecuteFolderTreeItems.Empty();
			return false;
		}
	}
	return true;
}

bool FColorOutlinerModule::InitialActorTreeItems()
{
	const TArray<FSceneOutlinerTreeItemPtr> NowExecuteItems = SelectedSceneOutliner.Pin()->GetSelectedItems();
	const int ExecuteItemsNum = NowExecuteItems.Num();
	ExecuteActorTreeItems.SetNum(ExecuteItemsNum);
			
	for(int i = 0; i < ExecuteItemsNum; ++i)
	{
		if(FActorTreeItem* SelectedActor = NowExecuteItems[i]->CastTo<FActorTreeItem>())
		{
			ExecuteActorTreeItems[i] = SelectedActor;
		}
		else
		{
			ExecuteActorTreeItems.Empty();
			return false;
		}
	}
	return true;
}

bool FColorOutlinerModule::CheckSelectedFoldersSetColor()
{
	for(const FActorFolderTreeItem* SelectedFolder : ExecuteFolderTreeItems)
	{
		const FString FullPath = OFUtils::GetFolderFullPath(SelectedFolder);
		
		const TOptional<FLinearColor> Color = OFUtils::GetIsTempMap()?
		OFUtils::GetColorByPathTemp(SelectedFolder->GetPath().ToString()) : OFUtils::GetColorByPath(FullPath,true);
				
		if (Color.IsSet())
		{
			if(!Color->Equals(OFUtils::GetOutlinerItemSetColor(true)))
			{
				ExistItemSetColor = Color.GetValue();
				return true;
			}
		}
	}
	return false;
}

bool FColorOutlinerModule::CheckSelectedActorsSetColor()
{
	for(const FActorTreeItem* SelectedActor : ExecuteActorTreeItems)
	{
		const FString FullPath = OFUtils::GetActorFullPath(SelectedActor);
		
		const TOptional<FLinearColor> Color = OFUtils::IsActorInTempMap(FullPath)?
		OFUtils::GetColorByPathTemp(OFUtils::GetGuidStringFromActorItem(SelectedActor)) : OFUtils::GetColorByPath(FullPath,false);
		 			
		if (Color.IsSet())
		{
			/*发现设置过颜色的actor, 开启clear按钮*/
			if(!Color->Equals(OFUtils::GetOutlinerItemSetColor(false)))
			{
				ExistItemSetColor = Color.GetValue();
				return true;
			}
		}
	}
	return false;
}

void FColorOutlinerModule::RegisterOnChangedPIEState()
{
	OnPIEStartedDelegate = FEditorDelegates::PostPIEStarted.AddLambda([&](const bool bIsSimulating)
	{
		IsInPIE = true;
	});
	OnPIEEndedDelegate = FEditorDelegates::EndPIE.AddLambda([&](const bool bIsSimulating)
	{
		IsInPIE = false;
	});
}

void FColorOutlinerModule::RegisterOnActiveTabChanged()
{
	OnActiveTabChangedHandle = FGlobalTabmanager::Get()->OnActiveTabChanged_Subscribe(FOnActiveTabChanged::FDelegate::CreateLambda(
	[this](TSharedPtr<SDockTab> PreviouslyTab, TSharedPtr<SDockTab> NewlyTab)
	{
		const static FText LevelsTabName = FText::FromString(TEXT("Levels"));
		if(NewlyTab.IsValid())
		{
			IsFocusOnLevelsTab = NewlyTab->GetTabLabel().EqualTo(LevelsTabName);
		}
		else
		{
			IsFocusOnLevelsTab = false;
		}
	
	}));
}

void FColorOutlinerModule::RegisterTickerCheckLevelLockState()
{
	auto OnTickEvent = [&](float DeltaTime) -> bool
	{
		/*tick调用, 尽可能减少计算以及最终刷新的执行,先过滤3个状态*/
		if(!IsCurrentPartitionedWorld && !IsInPIE && IsFocusOnLevelsTab)
		{
			const EMouseEvent MouseEvent = GetMouseEvent();
			if(MouseEvent != EMouseEvent::Default)
			{
				/*提前执行该函数是为了在鼠标按下时更新函数内静态int, 实际bool在松开时才有作用*/
				bool LockedLevelsNumChanged = GetLockedLevelsNumChanged();
				if(MouseEvent == EMouseEvent::Release && LockedLevelsNumChanged)
				{
					/*刷新关卡*/
					UCOEditorUtilityLibrary::RefreshSceneOutliners();
				}
			}
		}
		/*当返回false时, ticker被销毁*/
		return true;
	};
	
	TickCheckLevelLockStateHandle = FTSTicker::GetCoreTicker().AddTicker(TEXT("ColorOutlinerTicker"),0.0f,OnTickEvent);
}

EMouseEvent FColorOutlinerModule::GetMouseEvent()
{
	EMouseEvent MouseEvent = EMouseEvent::Default;
	if (!FSlateApplication::IsInitialized()) return MouseEvent;
	
	static bool LastTimeLeftMouseDown = false;
	bool NewTimeLeftMouseDown = FSlateApplication::Get().GetPressedMouseButtons().Contains(EKeys::LeftMouseButton);
	if(LastTimeLeftMouseDown != NewTimeLeftMouseDown)
	{
		if(NewTimeLeftMouseDown)
		{
			MouseEvent = EMouseEvent::Press;
		}
		else
		{
			MouseEvent = EMouseEvent::Release;
		}
		LastTimeLeftMouseDown = NewTimeLeftMouseDown;
	}

	return MouseEvent;
}

bool FColorOutlinerModule::GetLockedLevelsNumChanged() const
{
	if(!CurrentWorld.IsValid()) return false;
	
	static int LastLockedLevelsNum = 0;
	int NewLockedLevelsNum = 0;
	
	for(ULevel* Level : CurrentWorld->GetLevels())
	{
		if(Level!=nullptr && FLevelUtils::IsLevelLocked(Level))
		{
			NewLockedLevelsNum++;
		}
	}
	if(LastLockedLevelsNum != NewLockedLevelsNum)
	{
		LastLockedLevelsNum = NewLockedLevelsNum;
		return true;
	}
	return false;
}



#endif

#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(FColorOutlinerModule, ColorOutliner)