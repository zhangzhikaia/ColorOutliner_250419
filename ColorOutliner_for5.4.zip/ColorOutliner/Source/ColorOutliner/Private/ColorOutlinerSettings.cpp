﻿// Copyright lurongjiu 2024 All Rights Reserved.

#include "ColorOutlinerSettings.h"

#if WITH_EDITOR
#include "ColorOutlinerUtils.h"
#endif
//#include "Delegates/DelegateCombinations.h"

#define LOCTEXT_NAMESPACE "UColorOutlinerSettings"

PRAGMA_DISABLE_DEPRECATION_WARNINGS

FColorOutlinerSettingsDelegates::FOnPostEditChangeProperty  FColorOutlinerSettingsDelegates::OnPostEditChangeProperty;

PRAGMA_ENABLE_DEPRECATION_WARNINGS

UColorOutlinerSettings::UColorOutlinerSettings()
{
#if WITH_EDITOR
	DefaultFolderColor = SceneOutlinerFolderUtils::GetOutlinerFolderDefaultColor();
#else
	DefaultFolderColor = FLinearColor(0.467784,0.274677,0.090842,1);
#endif
	DefaultActorColor = FLinearColor::White;
}

FName UColorOutlinerSettings::GetCategoryName() const
{
	return TEXT("Plugins");
}

#if WITH_EDITOR
FText UColorOutlinerSettings::GetSectionText() const
{
	return LOCTEXT("ColorOutlinerSettings", "Color Outliner");
}

FName UColorOutlinerSettings::GetSectionName() const
{
	return TEXT("Color Outliner");
}

FText UColorOutlinerSettings::GetSectionDescription() const
{
	return LOCTEXT("ColorOutlinerSettingsTooltip","Color Outliner Settings.");
}

void UColorOutlinerSettings::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);
	
	FColorOutlinerSettingsDelegates::OnPostEditChangeProperty.Broadcast();

	if(ResetFolderColor)
	{
		SceneOutlinerFolderUtils::ResetDefaultColorInConfig(true);
		DefaultFolderColor = SceneOutlinerFolderUtils::GetOutlinerFolderDefaultColor();
		ResetFolderColor = false;
	}
	else if(ResetActorColor)
	{
		SceneOutlinerFolderUtils::ResetDefaultColorInConfig(false);
		DefaultActorColor = FLinearColor::White;
		ResetActorColor = false;
	}
	
	ExportActorsColorList = false;
	ImportActorsColorList = false;
}
#endif

#undef LOCTEXT_NAMESPACE