// Copyright lurongjiu 2024 All Rights Reserved.

#pragma once
#include "CoreMinimal.h"
#include "Modules/ModuleManager.h"

#if WITH_EDITOR
#include "SceneOutlinerFwd.h"

struct FActorFolderTreeItem;
class SSceneOutlinerTreeRow;
enum class EMouseEvent : uint8;
#endif

class FColorOutlinerModule : public IModuleInterface
{
public:
	/** IModuleInterface implementation */
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;

private:

#if WITH_EDITOR
	/*When map rename,change the saved path in config and TMap*/
	void RegisterOnMapRename();
	
	/*When map delete,clear the saved path in config and TMap*/
	void RegisterOnMapDeleted();

	/*When open/close/save map,update the saved data*/
	void RegisterOnMapChanged();

	/*When Outliner folders rename/move/delete,update the saved path in config and TMap*/
	void RegisterOnFolderOperate();
	
	/*When actor delete,remove its config color*/
	void RegisterOnActorDelete();
	

	/*When actors move to other streaming level,update its color in config*/
	void RegisterOnMoveActorsToLevel();

	/*When BlueprintCompiled, will execute actor delete event, fix it.*/
	void RegisterOnBlueprintCompile();
	
	static void RegisterOutlinerItemLabelColumn();

	void RegisterOutlinerContextMenuExtend();
	
	/*On Set Color, Open color picker*/
	void OutlinerItemExecutePickColor(const bool bIsFolder);
	
	/*ColorPickerOnColorChanged,Call OnColorClick*/
	void OnLinearColorValueChanged(const FLinearColor InColor,bool bIsFolder);

	/*Save Folder/Actor path and color in config */
	FReply OnFolderColorClicked(const FLinearColor InColor);
	FReply OnActorColorClicked(const FLinearColor InColor);
	
	/*Clear folder/actor path and color in config*/
	void OutlinerFolderExecuteResetColor();
	void OutlinerActorExecuteResetColor();

	/*从保存的成员获取大纲并刷新, 但需注意该成员只在操作大纲时有效,如需从蓝图或其他地方刷新大纲,需重新获取*/
	void RefreshCacheSceneOutliner();

#if ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION >= 1
	//tinted Filter
	static void RegisterTintedFilter();
#endif
	
	//修改设置时, 刷新列表
	void RegisterOnSettingsChanged();

	void InitialPropertyCache();

	/*右键打开items菜单时,初始化ExecuteFolder(Actor)TreeItems*/
	bool InitialFolderTreeItems();
	bool InitialActorTreeItems();

	/*检查所选items是否有设置过颜色, 如有, 保存下来, 并返回true*/
	bool CheckSelectedFoldersSetColor();
	bool CheckSelectedActorsSetColor();

	/*记录当前是否为PIE,是的话关卡无法锁定, 不执行tick*/
	void RegisterOnChangedPIEState();

	void RegisterOnActiveTabChanged();
	
	/*注册全局tick,检查关卡锁定状态*/
	void RegisterTickerCheckLevelLockState();

	/*tick调用,通过与上一帧的对比, 检查鼠标按下,松开, 减少多余的关卡锁定判断*/
	EMouseEvent GetMouseEvent();

	/*鼠标事件时调用, 通过与缓存的数量对比,发现关卡是否切换锁定*/
	bool GetLockedLevelsNumChanged() const;

private:
	/*Current active SceneOutliner*/
	TWeakPtr<SSceneOutliner> SelectedSceneOutliner;

#if ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION >= 1
	/*All opened SceneOutliner window*/
	TArray<TWeakPtr<ISceneOutliner>> SceneOutliners;
#endif
	/*todo:该成员没有实际作用,但仅在5.0中删除将导致崩溃,原因未知*/
	TArray<FSceneOutlinerTreeItemPtr> ExecuteItems;
	
	/*缓存对应子类型,避免过多次cast*/
	TArray<FActorFolderTreeItem*> ExecuteFolderTreeItems;
	TArray<FActorTreeItem*> ExecuteActorTreeItems;

	/*打开菜单时保存下已设置的颜色, 以便后续使用*/
	TOptional<FLinearColor> ExistItemSetColor;

	/*保存当前开启的关卡是否为大世界关卡, 若为大世界, 不用检查锁定*/
	bool IsCurrentPartitionedWorld = false;
	TWeakObjectPtr<UWorld> CurrentWorld;

	bool IsInPIE = false;
	bool IsFocusOnLevelsTab = false;
	
private:
	/*DelegateHandle*/
	FDelegateHandle OnPreWorldRenameHandle;
	FDelegateHandle OnPostWorldRenameHandle;
	
	FDelegateHandle OnAssetsPreDeleteHandle;
	FDelegateHandle OnAssetsDeletedHandle;
	
	FDelegateHandle OnMapChangedHandle;
	
	FDelegateHandle OnFolderMovedHandle;
	FDelegateHandle OnFolderDeletedHandle;

	FDelegateHandle OnLevelActorDeleted;

	FDelegateHandle OnMoveActorsToLevel;

	FDelegateHandle OnBlueprintPreCompile;
	FDelegateHandle OnBlueprintCompiled;

	FDelegateHandle OnSettingsChangedHandle;
	FDelegateHandle OnIOExecuteHandle;

	FDelegateHandle OnPIEStartedDelegate;
	FDelegateHandle OnPIEEndedDelegate;

	FDelegateHandle OnActiveTabChangedHandle;

	FTSTicker::FDelegateHandle TickCheckLevelLockStateHandle;

#endif
};
